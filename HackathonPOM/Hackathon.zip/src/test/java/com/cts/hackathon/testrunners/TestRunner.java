package com.cts.hackathon.testrunners;

import com.cts.hackathon.pageobjects.*;
import com.cts.miniproject.browserutils.BrowserFactory;
import com.cts.miniproject.frameworkutils.CommonUtil;
import com.cts.miniproject.frameworkutils.DataProvider;
import com.cts.miniproject.frameworkutils.PropertiesFileReader;
import com.cts.miniproject.seleniumutils.ScreenShotUtil;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class TestRunner {
    public static WebDriver driver = null;
    String bn = null;
    String url = null;
    String wr;
    String remoteip;
    BasePage basePage = null;
    CarLoan carloan=null;
    HomeLoan homeLoan = null;
    PersonalLoan personalLoan=null;
    EMICalculatorNew emiCalculatorNew=null;
    LoanAmountCalculator loanAmountCalculator=null;
    LoanTenureCalculator loanTenureCalculator=null;

    @BeforeMethod
    public void preSetup() throws Exception {

        try {
            bn = PropertiesFileReader.getPropertyValue("config", "browsername");
            wr = PropertiesFileReader.getPropertyValue("config", "wheretorun");
            remoteip = PropertiesFileReader.getPropertyValue("config", "hubip");
            url = PropertiesFileReader.getPropertyValue("config", "url");


            driver = BrowserFactory.getBrowser(bn,url);
            BrowserFactory.openurl(url);
            System.out.println("Driver created successfully.");
            basePage = new BasePage(driver);
            carloan = new CarLoan(driver);
            homeLoan = new HomeLoan(driver);
            personalLoan=new PersonalLoan(driver);
            emiCalculatorNew=new EMICalculatorNew(driver);
            loanAmountCalculator=new LoanAmountCalculator(driver);
            loanTenureCalculator=new LoanTenureCalculator(driver);

        } catch (Exception e) {
            throw e;
        }
    }
    /*
    @Test(dataProvider="mp",dataProviderClass= DataProvider.class ,priority = 0)
    public void carLoanAmountCaluclate(String amount,String interestRate,String tenure) throws Exception{
        try{
            carloan.clickCarLoan();
            carloan.setLoanAmount(amount);
            carloan.setInterest(interestRate);
            carloan.setLoanTenure(tenure);
            CommonUtil.sureWait(3);
            carloan.clickYear2025();
            System.out.println(carloan.getPrincipleAmount());
            System.out.println(carloan.getInterestAmount());
        }
        catch(Exception e){
            ScreenShotUtil.takeScreenShot(driver);
            System.out.println(e.getMessage());
        }
    }

    @Test(dataProvider="mp",dataProviderClass= DataProvider.class ,priority = 1)
    public void printYearlyTable(String amount,String interestRate,String tenure) throws Exception{
        try{
            homeLoan.setHomeLoanAmount(amount);
            homeLoan.setInterestRate(interestRate);
            homeLoan.setLoanTenure(tenure);
            homeLoan.clickYear();
            homeLoan.printYearTableData();
        }
        catch(Exception e){
            ScreenShotUtil.takeScreenShot(driver);
            System.out.println(e.getMessage());
        }
    }

    @Test(dataProvider="mp",dataProviderClass= DataProvider.class ,priority = 2)
    public void validateUIElements() throws Exception{
        try{
            emiCalculator.openingLoanCalculatorPage();

            boolean sliderChange  =emiCalculator.compareChangeInSlider();
            Assert.assertTrue(sliderChange,"The values in the slider did not change");

            boolean validateEmiElements = emiCalculator.validateEmiElements();
            Assert.assertTrue(validateEmiElements, "All the elements in EMI page did not pass the UI check");

            emiCalculator.openingLoanAmountCalculatorPage();
            boolean validateLoanAmountElements = loanAmountCalculator.validateLoanAmountElements();
            Assert.assertTrue(validateLoanAmountElements, "All the elements in Loan Amount page did not pass the UI check");

            loanAmountCalculator.openingLoanTenureCalculatorPage();
            boolean validateLoanTenureElements = loanTenureCalculator.validateLoanTenureElements();
            Assert.assertTrue(validateLoanTenureElements, "All the elements in Loan Tenure page did not pass the UI check");

        }
        catch(Exception e){
            ScreenShotUtil.takeScreenShot(driver);
            System.out.println(e.getMessage());
        }
    }*/

    @Test(dataProvider="mp", dataProviderClass= DataProvider.class, priority = 0)
    public void launchEMICalcPage(String expectedTitle) throws Exception {
        try {
            String title= basePage.getPageTitle();
            Assert.assertEquals(title,expectedTitle,"Page Title mismatch");
        } catch(Exception e) {
            ScreenShotUtil.takeScreenShot(driver);
            System.out.println(e.getMessage());
        }
    }

    @Test(dataProvider="mp", dataProviderClass= DataProvider.class, priority = 1)
    public void openPersonalLoanCalc(String expectedLabel) throws Exception {
        try {
            basePage.clickPersonalLoan();
            String label=personalLoan.verifyPersonalLoanPage();
            Assert.assertEquals(label,expectedLabel,"page did not switch");
        } catch(Exception e) {
            ScreenShotUtil.takeScreenShot(driver);
            System.out.println(e.getMessage());
        }
    }

    @Test(dataProvider="mp", dataProviderClass= DataProvider.class, priority = 2)
    public void openCarLoanCalc(String expectedLabel) throws Exception {
        try {
            basePage.clickCarLoan();
            String label=carloan.verifyCarLoanPage();
            Assert.assertEquals(label,expectedLabel,"page did not switch");
        } catch(Exception e) {
            ScreenShotUtil.takeScreenShot(driver);
            System.out.println(e.getMessage());
        }
    }

    @Test(dataProvider="mp", dataProviderClass= DataProvider.class, priority = 3)
    public void calculateCarLoanEMI(String amount,String interestRate,String tenure,String expectedEMI) throws Exception {
        try {
            carloan.clickCarLoan();
            carloan.setLoanAmount(amount);
            carloan.setInterest(interestRate);
            carloan.setLoanTenure(tenure);
            carloan.clickYearButton();
            String emi=carloan.verifyCalculation();
            Assert.assertEquals(emi,expectedEMI,"mismatch of EMI");

        } catch(Exception e) {
            ScreenShotUtil.takeScreenShot(driver);
            System.out.println(e.getMessage());
        }
    }

    @Test(dataProvider="mp", dataProviderClass= DataProvider.class, priority = 4)
    public void viewFirstMonthBreakdown(String amount,String interestRate,String tenure,String expectedPrincipleAmount,String expectedInterestAmount) throws Exception {
        try {
            carloan.clickCarLoan();
            carloan.setLoanAmount(amount);
            carloan.setInterest(interestRate);
            carloan.setLoanTenure(tenure);
            carloan.clickYearButton();
            CommonUtil.sureWait(3);
            carloan.clickYear2025();
            String principleAmount=carloan.getPrincipleAmount();
            String interestAmount=carloan.getInterestAmount();
            Assert.assertEquals(principleAmount,expectedPrincipleAmount,"principle amount mismatch");
            Assert.assertEquals(interestAmount,expectedInterestAmount,"interest amount mismatch");
        } catch(Exception e) {
            ScreenShotUtil.takeScreenShot(driver);
            System.out.println(e.getMessage());
        }
    }

    @Test(dataProvider="mp", dataProviderClass= DataProvider.class, priority = 5)
    public void updateInterestRecalculate(String amount,String interestRate,String tenure,String expectedPrincipleAmount,String expectedInterestAmount) throws Exception {
        try {
            carloan.clickCarLoan();
            carloan.setLoanAmount(amount);
            carloan.setInterest(interestRate);
            carloan.setLoanTenure(tenure);
            carloan.clickYearButton();
            CommonUtil.sureWait(3);
            carloan.clickYear2025();
            String principleAmount=carloan.getPrincipleAmount();
            String interestAmount=carloan.getInterestAmount();
            Assert.assertEquals(principleAmount,expectedPrincipleAmount,"principle amount mismatch");
            Assert.assertEquals(interestAmount,expectedInterestAmount,"interest amount mismatch");
        } catch(Exception e) {
            ScreenShotUtil.takeScreenShot(driver);
            System.out.println(e.getMessage());
        }
    }

    @Test(dataProvider="mp", dataProviderClass= DataProvider.class, priority = 6)
    public void updateTenureRecalculate(String amount,String interestRate,String tenure,String expectedPrincipleAmount,String expectedInterestAmount) throws Exception {
        try {
            carloan.clickCarLoan();
            carloan.setLoanAmount(amount);
            carloan.setInterest(interestRate);
            carloan.setLoanTenure(tenure);
            CommonUtil.sureWait(3);
            carloan.clickYear2025();
            String principleAmount=carloan.getPrincipleAmount();
            String interestAmount=carloan.getInterestAmount();
            Assert.assertEquals(principleAmount,expectedPrincipleAmount,"principle amount mismatch");
            Assert.assertEquals(interestAmount,expectedInterestAmount,"interest amount mismatch");
        } catch(Exception e) {
            ScreenShotUtil.takeScreenShot(driver);
            System.out.println(e.getMessage());
        }
    }

    @Test(dataProvider="mp", dataProviderClass= DataProvider.class, priority = 7)
    public void updateLoanAmountRecalculate(String amount,String interestRate,String tenure,String expectedPrincipleAmount,String expectedInterestAmount) throws Exception {
        try {
            carloan.clickCarLoan();
            carloan.setLoanAmount(amount);
            carloan.setInterest(interestRate);
            carloan.setLoanTenure(tenure);
            CommonUtil.sureWait(3);
            carloan.clickYear2025();
            String principleAmount=carloan.getPrincipleAmount();
            String interestAmount=carloan.getInterestAmount();
            Assert.assertEquals(principleAmount,expectedPrincipleAmount,"principle amount mismatch");
            Assert.assertEquals(interestAmount,expectedInterestAmount,"interest amount mismatch");
        } catch(Exception e) {
            ScreenShotUtil.takeScreenShot(driver);
            System.out.println(e.getMessage());
        }
    }

    @Test(dataProvider="mp", dataProviderClass= DataProvider.class, priority = 8)
    public void openHomeLoanCalc(String expectedLabel) throws Exception {
        try {
            basePage.clickHomeLoan();
            String label=homeLoan.verifyHomeLoanPage();
            Assert.assertEquals(label,expectedLabel,"page did not switch");
        } catch(Exception e) {
            ScreenShotUtil.takeScreenShot(driver);
            System.out.println(e.getMessage());
        }
    }

    @Test(dataProvider="mp", dataProviderClass= DataProvider.class, priority = 9)
    public void calculateHomeLoanEMI(String amount,String interestRate,String tenure) throws Exception {
        try {
            homeLoan.setHomeLoanAmount(amount);
            homeLoan.setInterestRate(interestRate);
            homeLoan.setLoanTenure(tenure);
            homeLoan.clickYear();
            boolean checkTable=homeLoan.checkTable();
            Assert.assertTrue(checkTable,"Table not enabled");
        } catch(Exception e) {
            ScreenShotUtil.takeScreenShot(driver);
            System.out.println(e.getMessage());
        }
    }

    @Test(dataProvider="mp", dataProviderClass= DataProvider.class, priority = 10)
    public void verifyYearlyTableRowCount(String amount,String interestRate,String tenure, String rows) throws Exception {
        try {
            homeLoan.setHomeLoanAmount(amount);
            homeLoan.setInterestRate(interestRate);
            homeLoan.setLoanTenure(tenure);
            homeLoan.clickYear();
            int expectedRows = Integer.parseInt(rows);
            int rowNo =  homeLoan.noOfRows();
            Assert.assertEquals(rowNo, expectedRows,"row count mismatch");
        } catch(Exception e) {
            ScreenShotUtil.takeScreenShot(driver);
            System.out.println(e.getMessage());
        }
    }

    @Test(dataProvider="mp", dataProviderClass= DataProvider.class, priority = 11)
    public void exportEMITableToExcel(String amount,String interestRate,String tenure) throws Exception {
        try {
            homeLoan.setHomeLoanAmount(amount);
            homeLoan.setInterestRate(interestRate);
            homeLoan.setLoanTenure(tenure);
            homeLoan.clickYear();
            boolean table=homeLoan.printYearTableData();
            Assert.assertTrue(table,"error while exporting data");
        } catch(Exception e) {
            ScreenShotUtil.takeScreenShot(driver);
            System.out.println(e.getMessage());
        }
    }

    @Test(dataProvider="mp", dataProviderClass= DataProvider.class, priority = 12)
    public void checkEMICalcInputFields() throws Exception {
        emiCalculatorNew.openingLoanCalculatorPage();
        emiCalculatorNew.initializeTxtElementList();
        emiCalculatorNew.initializeSliderElementList();
        boolean emiTxtElements = emiCalculatorNew.validateEmiTxtElements();
        Assert.assertTrue(emiTxtElements, "Input Boxes Element Mismatch in EMI Calculator");
        try {
        } catch(Exception e) {
            ScreenShotUtil.takeScreenShot(driver);
            System.out.println(e.getMessage());
        }
    }

    @Test(dataProvider="mp", dataProviderClass= DataProvider.class, priority = 13)
    public void checkEMICalcSliders() throws Exception {
        try {
            boolean emiSliderElements = emiCalculatorNew.validateEmiSliderElements();
            Assert.assertTrue(emiSliderElements, "Slider Element Mismatch in EMI Calculator");
        } catch(Exception e) {
            ScreenShotUtil.takeScreenShot(driver);
            System.out.println(e.getMessage());
        }
    }

    @Test(dataProvider="mp", dataProviderClass= DataProvider.class, priority = 14)
    public void checkLoanAmountInputFields() throws Exception {
        try {
            boolean loanAmountTxtElements = loanAmountCalculator.validateLoanAmountTxtElements();
            Assert.assertTrue(loanAmountTxtElements, "Input Boxes Element Mismatch in Loan Amount Calculator");
        } catch(Exception e) {
            ScreenShotUtil.takeScreenShot(driver);
            System.out.println(e.getMessage());
        }
    }

    @Test(dataProvider="mp", dataProviderClass= DataProvider.class, priority = 15)
    public void checkLoanAmountSliders() throws Exception {
        try {
            boolean loanAmountSliderElements = loanAmountCalculator.validateLoanAmountSliderElements();
            Assert.assertTrue(loanAmountSliderElements, "Slider Element Mismatch in Loan Amount Calculator");
        } catch(Exception e) {
            ScreenShotUtil.takeScreenShot(driver);
            System.out.println(e.getMessage());
        }
    }

    @Test(dataProvider="mp", dataProviderClass= DataProvider.class, priority = 16)
    public void checkLoanTenureInputFields() throws Exception {

        try {
            boolean loanTenureTxtElements = loanTenureCalculator.validateLoanTenureSliderElements();
            Assert.assertTrue(loanTenureTxtElements, "Input Boxes Element Mismatch in Loan Tenure Calculator");
        } catch(Exception e) {
            ScreenShotUtil.takeScreenShot(driver);
            System.out.println(e.getMessage());
        }
    }

    @Test(dataProvider="mp", dataProviderClass= DataProvider.class, priority = 17)
    public void checkLoanTenureSliders() throws Exception {
        try {
            boolean loanTenureSliderElements = loanTenureCalculator.validateLoanTenureSliderElements();
            Assert.assertTrue(loanTenureSliderElements, "Slider element mismatch in Loan Tenure Calculator");
        } catch(Exception e) {
            ScreenShotUtil.takeScreenShot(driver);
            System.out.println(e.getMessage());
        }
    }

    @Test(dataProvider="mp", dataProviderClass= DataProvider.class, priority = 18)
    public void verifyTenureScaleChange() throws Exception {
        try {
            boolean sliderCheck = emiCalculatorNew.compareChangeInSlider();
            Assert.assertTrue(sliderCheck, "Slider change Mismatch");
        } catch(Exception e) {
            ScreenShotUtil.takeScreenShot(driver);
            System.out.println(e.getMessage());
        }
    }

    @AfterClass
    public void postTest(){
        try {
            Thread.sleep(3000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
        driver.close();
        driver.quit();
    }

}
